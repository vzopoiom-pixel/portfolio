import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from config import settings
from database.connection import init_db
from handlers import start, funnel, webapp
from middlewares.check_sub import CheckSubscriptionMiddleware
from services.scheduler import start_scheduler

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


async def main() -> None:
    # 1. Init DB
    await init_db()
    logger.info("Database initialised")

    # 2. Start scheduler
    start_scheduler()
    logger.info("Scheduler started")

    # 3. Create bot & dispatcher
    bot = Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher()

    # 4. Register middleware
    dp.message.middleware(CheckSubscriptionMiddleware())

    # 5. Include routers
    dp.include_router(start.router)
    dp.include_router(funnel.router)
    dp.include_router(webapp.router)

    # 6. Start polling
    logger.info("Bot is starting…")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    asyncio.run(main())
